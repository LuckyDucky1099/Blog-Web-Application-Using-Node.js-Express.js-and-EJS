// ============================================================
//  MiniBlog - server.js
//  A simple blog app built while learning Node.js + Express.
//  Everything is explained with comments since this is a
//  learning project, not a "real" production app.
// ============================================================

// 1. Bring in the tools (packages) we need.
const express = require('express');   // the web server framework
const path = require('path');         // helps build file paths safely

// 2. Create the Express app.
const app = express();
const PORT = 3000;

// 3. Tell Express which "template engine" to use for pages.
//    EJS lets us write normal HTML but plug in JavaScript values.
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// 4. Middleware - code that runs on every request before our routes.
//    This line lets us read data submitted from HTML <form> elements
//    (req.body will be empty/undefined without it).
app.use(express.urlencoded({ extended: true }));

//    This line lets us serve our CSS file from the "public" folder.
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
//  "Database"
//  We don't have a real database in this project. Instead we
//  just keep an array of post objects in memory. That means:
//  every time we restart the server, we lose all the posts!
// ============================================================

let posts = [
  {
    id: 1,
    title: 'Welcome to MiniBlog!',
    author: 'Admin',
    category: 'Tech',
    content: 'This is a sample post to show you how the blog looks. Feel free to edit or delete it, or create your own post using the form above!',
    createdAt: new Date(),
  },
  {
    id: 2,
    title: 'Five Tips for a Healthier Lifestyle',
    author: 'Jamie Health',
    category: 'Lifestyle',
    content: 'Drink more water, sleep at least 7 hours, take walking breaks, eat more greens, and practice gratitude daily. Small habits add up!',
    createdAt: new Date(),
  },
];

// Every new post gets the next number in line. Starts at 3 because
// we already used id 1 and 2 for the sample posts above.
let nextId = 3;

// The list of categories a post can belong to.
const CATEGORIES = ['Tech', 'Lifestyle', 'Education', 'Travel', 'Food', 'Other'];

// ============================================================
//  Routes
//  A "route" is just: when a certain URL is visited (with a
//  certain method, like GET or POST), run this function.
// ============================================================

// --- HOME PAGE: show all posts ---
// Visiting "/" or "/?category=Tech" lands here.
app.get('/', (req, res) => {
  const selectedCategory = req.query.category || 'All';

  let postsToShow = posts;
  if (selectedCategory !== 'All') {
    postsToShow = posts.filter((post) => post.category === selectedCategory);
  }

  res.render('index', {
    title: 'MiniBlog',
    posts: postsToShow,
    categories: CATEGORIES,
    activeCategory: selectedCategory,
  });
});

// --- SHOW THE "NEW POST" FORM ---
app.get('/posts/new', (req, res) => {
  res.render('new', { title: 'New Post', categories: CATEGORIES });
});

// --- HANDLE THE "NEW POST" FORM BEING SUBMITTED ---
app.post('/posts', (req, res) => {
  // req.body holds whatever the user typed into the form fields.
  const author = req.body.author;
  const title = req.body.title;
  const content = req.body.content;
  const category = req.body.category;

  // Very basic validation: make sure the important fields aren't empty.
  if (!author || !title || !content) {
    return res.render('new', {
      title: 'New Post',
      categories: CATEGORIES,
      error: 'Please fill in your name, a title, and some content.',
    });
  }

  // Build a new post object and add it to our posts array.
  const newPost = {
    id: nextId,
    author: author,
    title: title,
    content: content,
    category: category || 'Other',
    createdAt: new Date(),
  };
  nextId = nextId + 1;

  posts.push(newPost);

  // Send the user back to the homepage to see their new post.
  res.redirect('/');
});

// --- SHOW ONE SINGLE POST ---
// The ":id" part is a placeholder - Express fills it in with
// whatever number is actually in the URL, e.g. /posts/2
app.get('/posts/:id', (req, res) => {
  const postId = Number(req.params.id);
  const post = posts.find((p) => p.id === postId);

  if (!post) {
    return res.status(404).render('404', { title: 'Post Not Found' });
  }

  res.render('show', { title: post.title, post: post });
});

// --- SHOW THE "EDIT POST" FORM, PRE-FILLED WITH EXISTING DATA ---
app.get('/posts/:id/edit', (req, res) => {
  const postId = Number(req.params.id);
  const post = posts.find((p) => p.id === postId);

  if (!post) {
    return res.status(404).render('404', { title: 'Post Not Found' });
  }

  res.render('edit', { title: 'Edit Post', post: post, categories: CATEGORIES });
});

// --- HANDLE THE "EDIT POST" FORM BEING SUBMITTED ---
// Note: we use POST here (not PUT) to keep things simple.
// Plain HTML forms can only send GET or POST anyway.
app.post('/posts/:id/edit', (req, res) => {
  const postId = Number(req.params.id);
  const post = posts.find((p) => p.id === postId);

  if (!post) {
    return res.status(404).render('404', { title: 'Post Not Found' });
  }

  const author = req.body.author;
  const title = req.body.title;
  const content = req.body.content;
  const category = req.body.category;

  if (!author || !title || !content) {
    return res.render('edit', {
      title: 'Edit Post',
      post: { ...post, author, title, content, category },
      categories: CATEGORIES,
      error: 'Please fill in your name, a title, and some content.',
    });
  }

  // Update the post's fields with the new values.
  post.author = author;
  post.title = title;
  post.content = content;
  post.category = category || 'Other';

  res.redirect('/');
});

// --- HANDLE DELETING A POST ---
app.post('/posts/:id/delete', (req, res) => {
  const postId = Number(req.params.id);

  // Keep every post EXCEPT the one whose id matches.
  posts = posts.filter((post) => post.id !== postId);

  res.redirect('/');
});

// --- 404 PAGE (catches any URL that didn't match a route above) ---
app.use((req, res) => {
  res.status(404).render('404', { title: 'Page Not Found' });
});

// ============================================================
//  Start the server
// ============================================================
app.listen(PORT, () => {
  console.log('MiniBlog server running at http://localhost:' + PORT);
});
