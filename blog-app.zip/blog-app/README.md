# MiniBlog — Node.js + Express + EJS Blog App

A simple, responsive blog web app where anyone can create, view, edit, and delete
posts. Posts are stored **in memory only** — restarting the server resets the data
(no database, as specified).

## Features

- **Create** posts with author name, title, content, category, and an auto-set timestamp
- **View** all posts on the homepage, and read a full post on its own page
- **Edit** any post via a pre-filled form
- **Delete** any post (no user accounts — anyone can delete anything)
- **Bonus: Categories** — assign a category (Tech, Lifestyle, Education, Travel,
  Food, Other) to each post and filter the homepage by category using the chip bar
- Responsive, custom-styled UI (no Bootstrap — hand-written CSS with a warm
  editorial look) that works on desktop and mobile
- Friendly 404 page and basic form validation (empty-field errors)

## Project structure

```
blog-app/
├── server.js              # Express app, routes, in-memory posts array
├── views/
│   ├── index.ejs           # Homepage — post list + category filter
│   ├── show.ejs             # Single post view
│   ├── new.ejs               # Create-post form
│   ├── edit.ejs               # Edit-post form (pre-filled)
│   ├── 404.ejs                 # Not-found page
│   └── partials/
│       ├── header.ejs          # <head>, nav
│       └── footer.ejs          # closing tags, footer
├── public/
│   └── css/style.css       # All styling, responsive breakpoints included
└── package.json
```

## Routes

Kept intentionally simple — everything is just GET (visiting a page) or POST
(submitting a form), which is all a plain HTML `<form>` can send anyway.

| Method | Path                | Purpose                                |
|--------|---------------------|------------------------------------------|
| GET    | `/`                 | List all posts (supports `?category=`)   |
| GET    | `/posts/new`        | Show "create post" form                  |
| POST   | `/posts`            | Create a new post                        |
| GET    | `/posts/:id`        | View a single post                       |
| GET    | `/posts/:id/edit`   | Show "edit post" form (pre-filled)       |
| POST   | `/posts/:id/edit`   | Save changes to a post                   |
| POST   | `/posts/:id/delete` | Delete a post                            |

Posts are given a simple incrementing number as an ID (1, 2, 3...) instead of
a generated UUID, to keep the data easy to read and reason about while learning.

## Getting started

```bash
# 1. Install dependencies
npm install

# 2. Start the server
npm start
# or, for auto-restart on file changes during development:
npm run dev

# 3. Open the app
# http://localhost:3000
```

## Tech used

- **Express.js** — routing and server
- **EJS** — server-rendered templates
- Plain CSS with custom design tokens (no framework) for a distinctive, responsive UI

Kept deliberately minimal — just two dependencies (`express` and `ejs`) so the
project stays easy to follow for anyone new to Node.js. Every route is a plain
GET or POST, and `server.js` is commented step by step.

## Notes / next steps

- Data is not persisted — swap the in-memory `posts` array for a database
  (MongoDB, PostgreSQL, SQLite, etc.) to persist posts across restarts.
- There are no user accounts, so anyone can edit or delete any post — this
  matches the assignment spec but would need auth for a real deployment.
